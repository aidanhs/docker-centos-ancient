# Initialization script for bash and sh
alias which='alias | /usr/bin/which --tty-only --read-alias --show-dot --show-tilde'
